/*
	大地老师专栏：https://www.itying.com/category-79-b0.html
	Golang仿小米商城项目实战视频教程地址：https://www.itying.com/goods-1143.html
*/
package main

import "fmt"

func main() {
	// fmt.Println("你好golang")
	fmt.Println("你好golang")

	fmt.Print("aaa")
	fmt.Print("bbb")
	fmt.Print("ccc")

	fmt.Println("aaa")

	fmt.Println("bbb")
	fmt.Println("ccc")

	fmt.Println("go", "python", "php", "javascript")
	fmt.Print("go", "python", "php", "javascript")

}
