package main

import (
	"fmt"
	"golang/tools"
)

func init() {
	fmt.Println("main init..")
}
func main() {

	tools.PrintInfo()
}
